package com.example.greennote;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        final Button noteBtn;
        final LinearLayout noteSec, editor;
        final EditText note, noteTest;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editor = findViewById(R.id.editor);
        noteBtn = findViewById(R.id.newNoteBtn);
        noteSec = findViewById(R.id.noteSection);
        noteTest = findViewById(R.id.note);
        note = new EditText(this);
        //


        noteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //create new instance of note view
                TextView n = new EditText(getBaseContext());
                //((ViewGroup)noteTest.getParent()).removeView(noteTest);
                n.setText(noteTest.getText());
                noteSec.addView(n,0);
                noteTest.setText("");


            }
        });
    }


}
